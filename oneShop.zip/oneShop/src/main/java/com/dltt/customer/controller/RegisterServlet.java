package com.dltt.customer.controller;

import com.dltt.customer.service.CustomerService;
import com.dltt.customer.vo.Customer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        获取请求中的参数 customerPhone与form表单中input标签的name属性值要一致
        String phone = request.getParameter("customerPhone");
//        将字符串转换为long类型
        long customerPhone = Long.parseLong(phone);
        String customerName = request.getParameter("customerName");
        String customerPwd = request.getParameter("customerPwd");
//        利用获取的三个参数创建Customer实例
        Customer customer = new Customer();
        customer.setCustomerPhone(customerPhone);
        customer.setCustomerName(customerName);
        customer.setCustomerPwd(customerPwd);
//        创建业务层实例
        CustomerService service = new CustomerService();
        //接收注册业务方法返回值并判断
        if(service.register(customer)){
//            向请求中设置属性
            request.setAttribute("msg","注册成功");
//            请求转发，跳转到目的页面
            request.getRequestDispatcher("login.jsp").forward(request,response);
        }else{
            request.setAttribute("msg","注册失败");
            request.getRequestDispatcher("register.jsp").forward(request,response);
        }
    }
}
