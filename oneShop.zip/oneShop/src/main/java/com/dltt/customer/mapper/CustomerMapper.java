package com.dltt.customer.mapper;

import com.dltt.customer.vo.Customer;

public interface CustomerMapper {
    int deleteByPrimaryKey(Long customerPhone);

    int insert(Customer row);

    int insertSelective(Customer row);

    Customer selectByPrimaryKey(Long customerPhone);

    int updateByPrimaryKeySelective(Customer row);

    int updateByPrimaryKey(Customer row);

    Customer selectCustomer(Customer customer);
}