package com.dltt.customer.controller;

import com.dltt.customer.service.CustomerService;
import com.dltt.customer.vo.Customer;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String phone = request.getParameter("customerPhone");
        long customerPhone = Long.parseLong(phone);
        String customerPwd = request.getParameter("customerPwd");
        CustomerService service = new CustomerService();
        Customer customer = new Customer();
        customer.setCustomerPhone(customerPhone);
        customer.setCustomerPwd(customerPwd);
        if(service.selectCustomer(customer)!=null){
            request.setAttribute("msg","登录成功");
            request.getRequestDispatcher("index.jsp").forward(request,response);
        }else{
            request.setAttribute("msg","登陆失败");
            request.getRequestDispatcher("login.jsp").forward(request,response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
