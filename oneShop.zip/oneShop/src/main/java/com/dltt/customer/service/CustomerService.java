package com.dltt.customer.service;

import com.dltt.customer.mapper.CustomerMapper;
import com.dltt.customer.vo.Customer;
import org.apache.ibatis.session.SqlSession;
import utils.GetSqlSessionUtil;

public class CustomerService {
    //service业务逻辑层，处理业务
//    注册业务
    public boolean register(Customer customer){
//        获取sqlsession对象
        SqlSession session = GetSqlSessionUtil.getSqlSession();
//        获取CustomerMapper代理对象
        CustomerMapper mapper = session.getMapper(CustomerMapper.class);
//        调用添加方法
        int result = mapper.insert(customer);
//        提交事务
        session.commit();
        if(result>0){
            return true;
        }
        return false;
    }

    public Customer selectCustomer(Customer customer){
        //        获取sqlsession对象
        SqlSession session = GetSqlSessionUtil.getSqlSession();
//        获取CustomerMapper代理对象
        CustomerMapper mapper = session.getMapper(CustomerMapper.class);
        return mapper.selectCustomer(customer);
    }
}
