package utils;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;

public class GetSqlSessionUtil {
    public static SqlSession getSqlSession(){
//        获取mybatis配置文件
        String resource = "config.xml";
        InputStream inputStream;
        {
            try {
//                开启输入流
                inputStream = Resources.getResourceAsStream(resource);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
//        根据输入流获取SqlSessionFactory对象
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
//        获取SqlSession对象
        SqlSession session = sqlSessionFactory.openSession();
        return session;
    }

}
